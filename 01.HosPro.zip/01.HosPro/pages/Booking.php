<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking | HosPro</title>
    <?php require_once('../src/components/links.php'); ?>
</head>
<body>
    <?php
    // Database connection
    $connection = new mysqli('localhost', 'root', '', 'thehosprodb');

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    // Generate a new booking ID
    function generateBookingID($connection) {
        $query = "SELECT MAX(booking_id) AS last_id FROM booking_details";
        $result = $connection->query($query);
        $row = $result->fetch_assoc();
        $last_id = $row['last_id'] ?? null;
        $new_number = $last_id ? intval(substr($last_id, 3)) + 1 : 1;
        return 'BK-' . str_pad($new_number, 4, '0', STR_PAD_LEFT);
    }

    // Insert booking details on form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $booking_id = generateBookingID($connection);
        $room_type = $_POST['room_type'];
        $number_of_guests = $_POST['number_of_guests'];
        $arrival_date = $_POST['arrival_date'];
        $arrival_time = $_POST['arrival_time'];
        $departure_date = $_POST['departure_date'];
        $departure_time = $_POST['departure_time'];
        $special_request = $_POST['special_request'];

        $insert_query = "
            INSERT INTO booking_details (
                booking_id, room_type, number_of_guests, arrival_date, arrival_time, departure_date, departure_time, special_request
            ) VALUES (
                '$booking_id', '$room_type', $number_of_guests, '$arrival_date', '$arrival_time', '$departure_date',
                '$departure_time', '$special_request'
            )
        ";

        if ($connection->query($insert_query) === TRUE) {
            echo "<script>alert('Booking successfully created!');</script>";
        } else {
            echo "<script>alert('Error: " . $connection->error . "');</script>";
        }
    }
    ?>
    <div class="dashboard align-items-center justify-content-center">
        <div>
            <div class="container my-4  w-50">
                <div class="row customiser_wrapper justify-items-center card-bg-glass py-3">

                    <div class="text-center">
                        <h5 class="fs-2 pb-4">Booking Form</h5>
                    </div>

                    <form method="POST" action="../backend/controller/process_booking.php">
                        <div class="row">
                            <div class="col-6">
                                <label for="room_type" class="form-label">Room Type</label>
                                <select name="room_type" class="form-select frm-input" id="room_type" required>
                                    <option value="" selected>Select Your Room Type</option>
                                    <option value="Luxury Room">Luxury Room</option>
                                    <option value="Deluxe Room">Deluxe Room</option>
                                    <option value="Premier Room">Premier Room</option>
                                    <option value="Classic Room">Classic Room</option>
                                    <option value="Normal Room">Normal Room</option>
                                </select>
                            </div>
                            <div class="mb-1 col-6">
                                <label for="number_of_guests" class="form-label">No. of Guests</label>
                                <input type="number" name="number_of_guests" class="frm-input form-control" id="number_of_guests" required>
                            </div>
                            <div class="mb-1 col-6">
                                <label for="arrival_date" class="form-label">Arrival Date</label>
                                <input type="date" name="arrival_date" class="frm-input form-control" id="arrival_date" required>
                            </div>
                            <div class="mb-1 col-6">
                                <label for="arrival_time" class="form-label">Arrival Time</label>
                                <input type="time" name="arrival_time" class="frm-input form-control" id="arrival_time" required>
                            </div>

                            <div class="mb-1 col-6">
                                <label for="departure_date" class="form-label">Departure Date</label>
                                <input type="date" name="departure_date" class="frm-input form-control" id="departure_date" required>
                            </div>
                            <div class="mb-1 col-6">
                                <label for="departure_time" class="form-label">Departure Time</label>
                                <input type="time" name="departure_time" class="frm-input form-control" id="departure_time" required>
                            </div>
                            <div class="mb-1 col-12">
                                <label for="special_request" class="form-label">Special Requests</label>
                                <textarea name="special_request" class="frm-input form-control" id="special_request" placeholder="Write Here"></textarea>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn btn-success w-100 button m-1">Book Now</button>
                        </div>
                    </form>
                    <p>
                  <a href="user-dash.php" class="fw-bold" style="text-decoration: none;">
                    Go Back
                  </a>
                </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
