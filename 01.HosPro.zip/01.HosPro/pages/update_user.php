<?php
// Database connection
$server_name = 'localhost';
$dbusername = 'root';
$dbpassword = '';
$dbname = 'thehosprodb';

// Create connection
$conn = new mysqli($server_name, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $new_password = $_POST['new_password'];

    // Assuming a session with user ID is set
    session_start();
    $user_id = $_SESSION['user_id'];

    // Update query
    $update_query = "UPDATE user_details SET 
                        user_name = '$user_name', 
                        user_email = '$user_email'";

    // Append password update if provided
    if (!empty($new_password)) {
        $update_query .= ", user_password = '$new_password'";
    }

    $update_query .= " WHERE user_id = '$user_id'";

    // Execute query
    if ($conn->query($update_query) === TRUE) {
        // Redirect to the dashboard
        header("Location: user-dash.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>
