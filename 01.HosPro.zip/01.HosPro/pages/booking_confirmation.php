<?php
$booking_id = $_GET['booking_id'] ?? 'Unknown';
echo "<h1>Booking Confirmed!</h1>";
echo "<p>Your Booking ID: $booking_id</p>";
header('location:user-dash.php');
?>
