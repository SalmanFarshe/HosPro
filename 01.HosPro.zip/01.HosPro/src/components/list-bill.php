<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Bill ID</th>
            <th>Bill Purpose</th>
            <th>Due</th>
            <th>Paid</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1011</td>
            <td>Electricity</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>1011</td>
            <td>Cylinder</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>1011</td>
            <td>Garbage Clean</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
    </tbody>
</table>