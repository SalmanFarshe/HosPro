<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Costing Purpose</th>
            <th>Due</th>
            <th>Paid</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Maintanence</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>Salary</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>Electricity</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        
    </tbody>
</table>