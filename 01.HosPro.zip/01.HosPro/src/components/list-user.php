<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <!-- Employee Rows (To be dynamically populated) -->
        <tr>
            <td>Mr. Salman</td>
            <td>+880 1234567989</td>
            <td>Ashulia,Savar,Dhaka</td>
            <td>Present</td>
            <td class="d-flex justify-content-between">
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal"
                    data-bs-target="#editUserModal">Edit</button>
                <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                    data-bs-target="#checkPassModal">Delete</button>
                <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                    data-bs-target="#profileUserModal">Profile</button>
                <button class="btn btn-sm btn-secondary" data-bs-toggle="modal"
                    data-bs-target="#reviewUserModal">Review</button>
            </td>
        </tr>
        <tr>
            <td>Mr. Salman</td>
            <td>+880 1234567989</td>
            <td>Ashulia,Savar,Dhaka</td>
            <td>Present</td>
            <td class="d-flex justify-content-between">
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal"
                    data-bs-target="#editUserModal">Edit</button>
                <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                    data-bs-target="#checkPassModal">Delete</button>
                <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                    data-bs-target="#profileUserModal">Profile</button>
                <button class="btn btn-sm btn-secondary" data-bs-toggle="modal"
                    data-bs-target="#reviewUserModal">Review</button>
            </td>
        </tr>
        <tr>
            <td>Mr. Salman</td>
            <td>+880 1234567989</td>
            <td>Ashulia,Savar,Dhaka</td>
            <td>Present</td>
            <td class="d-flex justify-content-between">
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal"
                    data-bs-target="#editUserModal">Edit</button>
                <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                    data-bs-target="#checkPassModal">Delete</button>
                <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                    data-bs-target="#profileUserModal">Profile</button>
                <button class="btn btn-sm btn-secondary" data-bs-toggle="modal"
                    data-bs-target="#reviewUserModal">Review</button>
            </td>
        </tr>
    </tbody>
</table>