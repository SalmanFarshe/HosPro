<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Date</th>
            <th>Bookings ID</th>
            <th>ID</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>09-09-2024</td>
            <td>1011</td>
            <td>1</td>
            <td> Present </td>
        </tr>
    </tbody>
</table>