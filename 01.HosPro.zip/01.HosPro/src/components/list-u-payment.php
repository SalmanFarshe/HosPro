<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Date</th>
            <th>Payments ID</th>
            <th>ID</th>
            <th>Due</th>
            <th>Paid</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>09-09-2024</td>
            <td>1011</td>
            <td>1</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
    </tbody>
</table>