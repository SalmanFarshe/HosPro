<table class="table card-bg-glass">
    <thead>
        <tr>
            <th>Payments ID</th>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No.</th>
            <th>Due</th>
            <th>Paid</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1011</td>
            <td>1</td>
            <td>Air John Doe</td>
            <td>Air_john@gmail.com</td>
            <td>01234567890</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>1012</td>
            <td>2</td>
            <td>Bir John Doe</td>
            <td>Bir_john@gmail.com</td>
            <td>01234567890</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
        <tr>
            <td>1013</td>
            <td>3</td>
            <td>Cir John Doe</td>
            <td>Cir_john@gmail.com</td>
            <td>01234567890</td>
            <td>1500 </td>
            <td>1500 </td>
            <td>3000 </td>
        </tr>
    </tbody>
</table>