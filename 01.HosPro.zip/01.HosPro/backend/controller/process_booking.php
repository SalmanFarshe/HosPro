<?php
// Database connection
$server_name = 'localhost';
$dbusername = 'root';
$dbpassword = '';
$dbname = 'thehosprodb';

$conn = new mysqli($server_name, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Include the generateID function
function generateID($table, $prefix, $id_column, $connection) {
    $query = "SELECT MAX($id_column) AS last_id FROM $table";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);

    $last_id = $row['last_id'] ?? null;
    $new_number = $last_id ? intval(substr($last_id, strlen($prefix))) + 1 : 1;

    return $prefix . str_pad($new_number, 2, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_booking_id = generateID('booking_details', 'BK-', 'booking_id', $conn);

    $room_type = $_POST['room_type'];
    $number_of_guests = $_POST['number_of_guests'];
    $arrival_date = $_POST['arrival_date'];
    $arrival_time = $_POST['arrival_time'];
    $departure_date = $_POST['departure_date'];
    $departure_time = $_POST['departure_time'];
    $special_request = $_POST['special_request'];

    $insert_query = "INSERT INTO booking_details 
        (booking_id,  room_type, number_of_guests, arrival_date, arrival_time, departure_date, departure_time, special_request) 
        VALUES 
        ('$new_booking_id','$room_type', '$number_of_guests', '$arrival_date', '$arrival_time', '$departure_date', '$departure_time', '$special_request')";

    if ($conn->query($insert_query) === TRUE) {
        echo "Booking Successful! Your Booking ID is: $new_booking_id";
        header("Location: ../../pages/user-dash.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>
